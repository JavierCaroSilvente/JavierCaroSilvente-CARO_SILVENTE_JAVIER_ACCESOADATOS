<?php
if(isset($_POST["firstname"])){

	$firstname=$_POST["firstname"];
	$lastname=$_POST["lastname"];
	$fullname=$_POST["fullname"];
	$title=$_POST["title"];
	$family=$_POST["family"];
	$_image=$_POST["image"];

	$servidor="localhost";
	$usuario="root";
	$password="";
	$dbname="gameofthrones";
	$conexion=mysqli_connect($servidor,$usuario,$password,$dbname);

	if(!$conexion){
		echo"Error en la conexiona MySQL: ".mysqli_connect_error();
		exit();
	}

	$sql="INSERT INTO personajes (firstname,lastname,fullname,title,family,image) VALUES ('".addslashes($firstname)."','".addslashes($lastname)."','".addslashes($fullname)."','".addslashes($title)."','".addslashes($family)."','".addslashes($_image)."')";
	
	if(mysqli_query($conexion,$sql)){
		echo"Registro insertado correctamente.";
	}else{
	echo"Error: ".$sql."<br>".mysqli_error($conexion);
	}
}
?>
